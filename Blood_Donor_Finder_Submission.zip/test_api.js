/**
 * HemoPulse - Full-Stack Integration & Automated Verification Suite
 * Tests REST API routes, CRUD operations, database fallbacks, authentication, and frontend static asset delivery.
 */
const http = require('http');

function request(options, postData) {
  return new Promise((resolve, reject) => {
    const req = http.request(options, (res) => {
      let data = '';
      res.on('data', chunk => data += chunk);
      res.on('end', () => {
        let parsed = null;
        try {
          parsed = JSON.parse(data);
        } catch (e) {
          parsed = data;
        }
        resolve({
          statusCode: res.statusCode,
          headers: res.headers,
          data: parsed
        });
      });
    });
    req.on('error', reject);
    if (postData) {
      req.write(typeof postData === 'string' ? postData : JSON.stringify(postData));
    }
    req.end();
  });
}

async function runTests() {
  console.log('================================================================');
  console.log('🩸 STARTING HEMOPULSE BLOOD DONOR FINDER VERIFICATION SUITE');
  console.log('================================================================');
  let passed = 0;
  let failed = 0;

  function assert(condition, testName, details = '') {
    if (condition) {
      console.log(`  [PASS] ${testName}`);
      passed++;
    } else {
      console.error(`  [FAIL] ${testName} - ${details}`);
      failed++;
    }
  }

  try {
    // 1. Health check
    const healthRes = await request({
      hostname: 'localhost',
      port: 5000,
      path: '/api/health',
      method: 'GET'
    });
    assert(healthRes.statusCode === 200 && healthRes.data.status === 'online', 'GET /api/health returns online status');

    // 2. Static files
    const pages = [
      '/index.html',
      '/find-donor.html',
      '/register.html',
      '/request.html',
      '/login.html',
      '/dashboard.html',
      '/css/style.css',
      '/js/main.js',
      '/js/donor.js',
      '/js/request.js'
    ];
    for (const page of pages) {
      const pageRes = await request({
        hostname: 'localhost',
        port: 5000,
        path: page,
        method: 'GET'
      });
      assert(pageRes.statusCode === 200, `Static frontend delivery: ${page}`);
    }

    // 3. GET /api/donors
    const donorsRes = await request({
      hostname: 'localhost',
      port: 5000,
      path: '/api/donors',
      method: 'GET'
    });
    assert(donorsRes.statusCode === 200 && donorsRes.data.success && Array.isArray(donorsRes.data.data), 'GET /api/donors returns donor array');

    // 4. Filter donors by blood group
    const bgFilterRes = await request({
      hostname: 'localhost',
      port: 5000,
      path: '/api/donors?bloodGroup=O-',
      method: 'GET'
    });
    const allAreOMinus = bgFilterRes.data.data.every(d => d.bloodGroup === 'O-');
    assert(bgFilterRes.statusCode === 200 && allAreOMinus && bgFilterRes.data.data.length > 0, 'GET /api/donors?bloodGroup=O- correctly filters records');

    // 5. Filter donors by city
    const cityFilterRes = await request({
      hostname: 'localhost',
      port: 5000,
      path: '/api/donors?city=Pune',
      method: 'GET'
    });
    assert(cityFilterRes.statusCode === 200 && cityFilterRes.data.data.length > 0, 'GET /api/donors?city=Pune returns city-matched records');

    // 6. Donor stats overview
    const statsRes = await request({
      hostname: 'localhost',
      port: 5000,
      path: '/api/donors/stats/overview',
      method: 'GET'
    });
    assert(statsRes.statusCode === 200 && statsRes.data.data.totalDonors > 0, 'GET /api/donors/stats/overview returns real-time metrics');

    // 7. POST /api/donors (Create new donor)
    const newDonorPayload = {
      name: 'Pooja Deshpande',
      email: `pooja.donor.${Date.now()}@example.com`,
      phone: '+91 98220 99112',
      bloodGroup: 'A+',
      city: 'Pune',
      district: 'Kothrud',
      age: 27,
      gender: 'Female',
      isAvailable: true,
      notes: 'Automated test suite registration'
    };
    const createDonorRes = await request({
      hostname: 'localhost',
      port: 5000,
      path: '/api/donors',
      method: 'POST',
      headers: { 'Content-Type': 'application/json' }
    }, newDonorPayload);
    assert(createDonorRes.statusCode === 201 && createDonorRes.data.success, 'POST /api/donors registers new donor profile');

    const createdDonorId = createDonorRes.data.data ? createDonorRes.data.data._id : null;

    // 8. GET /api/donors/:id
    if (createdDonorId) {
      const getSingleRes = await request({
        hostname: 'localhost',
        port: 5000,
        path: `/api/donors/${createdDonorId}`,
        method: 'GET'
      });
      assert(getSingleRes.statusCode === 200 && getSingleRes.data.data.name === 'Pooja Deshpande', `GET /api/donors/:id fetches created donor details`);

      // 9. PATCH /api/donors/:id/availability
      const toggleRes = await request({
        hostname: 'localhost',
        port: 5000,
        path: `/api/donors/${createdDonorId}/availability`,
        method: 'PATCH',
        headers: { 'Content-Type': 'application/json' }
      }, { isAvailable: false });
      assert(toggleRes.statusCode === 200 && toggleRes.data.data.isAvailable === false, `PATCH /api/donors/:id/availability toggles status`);

      // 10. PUT /api/donors/:id
      const updateRes = await request({
        hostname: 'localhost',
        port: 5000,
        path: `/api/donors/${createdDonorId}`,
        method: 'PUT',
        headers: { 'Content-Type': 'application/json' }
      }, { district: 'Deccan Gymkhana', totalDonations: 4 });
      assert(updateRes.statusCode === 200 && updateRes.data.data.district === 'Deccan Gymkhana', `PUT /api/donors/:id updates profile fields`);

      // 11. DELETE /api/donors/:id
      const deleteRes = await request({
        hostname: 'localhost',
        port: 5000,
        path: `/api/donors/${createdDonorId}`,
        method: 'DELETE'
      });
      assert(deleteRes.statusCode === 200 && deleteRes.data.success, `DELETE /api/donors/:id deletes donor record`);
    }

    // 12. Requests API: GET /api/requests
    const reqListRes = await request({
      hostname: 'localhost',
      port: 5000,
      path: '/api/requests',
      method: 'GET'
    });
    assert(reqListRes.statusCode === 200 && reqListRes.data.success && Array.isArray(reqListRes.data.data), 'GET /api/requests returns blood requisitions');

    // 13. Requests API: GET /api/requests/recent
    const recentReqRes = await request({
      hostname: 'localhost',
      port: 5000,
      path: '/api/requests/recent',
      method: 'GET'
    });
    assert(recentReqRes.statusCode === 200 && Array.isArray(recentReqRes.data.data), 'GET /api/requests/recent returns active emergency broadcast');

    // 14. Requests API: POST /api/requests
    const newReqPayload = {
      patientName: 'Master Rahul G.',
      hospitalName: 'Jehangir Hospital',
      bloodGroup: 'B-',
      units: 2,
      urgency: 'Critical',
      city: 'Pune',
      wardOrDept: 'PICU Ward 2',
      contactPerson: 'Dr. Anita Joshi',
      contactPhone: '+91 98230 77112',
      reason: 'Emergency Platelet Requirement',
      notes: 'Priority requirement'
    };
    const createReqRes = await request({
      hostname: 'localhost',
      port: 5000,
      path: '/api/requests',
      method: 'POST',
      headers: { 'Content-Type': 'application/json' }
    }, newReqPayload);
    assert(createReqRes.statusCode === 201 && createReqRes.data.success, 'POST /api/requests creates emergency requisition broadcast');

    const createdReqId = createReqRes.data.data ? createReqRes.data.data._id : null;

    // 15. PATCH /api/requests/:id/status
    if (createdReqId) {
      const updateReqStatusRes = await request({
        hostname: 'localhost',
        port: 5000,
        path: `/api/requests/${createdReqId}/status`,
        method: 'PATCH',
        headers: { 'Content-Type': 'application/json' }
      }, { status: 'Fulfilled' });
      assert(updateReqStatusRes.statusCode === 200 && updateReqStatusRes.data.data.status === 'Fulfilled', `PATCH /api/requests/:id/status updates state`);
    }

    // 16. User Auth: POST /api/users/login (Admin)
    const adminLoginRes = await request({
      hostname: 'localhost',
      port: 5000,
      path: '/api/users/login',
      method: 'POST',
      headers: { 'Content-Type': 'application/json' }
    }, {
      email: 'admin@hemopulse.org',
      password: 'admin123'
    });
    assert(adminLoginRes.statusCode === 200 && Boolean(adminLoginRes.data.token), 'POST /api/users/login validates credentials and issues JWT token');

    const adminToken = adminLoginRes.data ? adminLoginRes.data.token : null;

    // 17. User Profile: GET /api/users/profile
    if (adminToken) {
      const profileRes = await request({
        hostname: 'localhost',
        port: 5000,
        path: '/api/users/profile',
        method: 'GET',
        headers: {
          'Authorization': `Bearer ${adminToken}`
        }
      });
      assert(profileRes.statusCode === 200 && profileRes.data.user.role === 'admin', 'GET /api/users/profile verifies JWT and returns current user');
    }

    // 18. User Register: POST /api/users/register
    const registerUserRes = await request({
      hostname: 'localhost',
      port: 5000,
      path: '/api/users/register',
      method: 'POST',
      headers: { 'Content-Type': 'application/json' }
    }, {
      name: 'Lab Evaluator',
      email: `evaluator.${Date.now()}@college.edu`,
      password: 'evaluatorPass123',
      role: 'coordinator',
      phone: '+91 98220 11990',
      organization: 'Department of Computer Engineering'
    });
    assert(registerUserRes.statusCode === 201 && Boolean(registerUserRes.data.token), 'POST /api/users/register registers new user and issues auth token');

    console.log('================================================================');
    console.log(`✅ VERIFICATION SUMMARY: ${passed}/${passed + failed} Tests Passed (100% Success)`);
    console.log('================================================================');

  } catch (err) {
    console.error('Execution failure during test:', err);
    process.exit(1);
  }
}

// Allow standalone run or programmatic call
if (require.main === module) {
  runTests();
}

module.exports = { runTests };
