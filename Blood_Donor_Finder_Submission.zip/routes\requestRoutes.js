const express = require('express');
const router = express.Router();
const requestController = require('../controllers/requestController');

// Recent emergency feeds for ticker & spotlight
router.get('/recent', requestController.getRecentEmergencies);

// Blood Request CRUD
router.get('/', requestController.getAllRequests);
router.get('/:id', requestController.getRequestById);
router.post('/', requestController.createRequest);
router.patch('/:id/status', requestController.updateRequestStatus);
router.delete('/:id', requestController.deleteRequest);

module.exports = router;
