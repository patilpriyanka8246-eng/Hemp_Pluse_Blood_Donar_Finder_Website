const BloodRequest = require('../models/BloodRequest');
const { isMongoConnected, memoryStore } = require('../db');

/**
 * GET /api/requests
 * Query filters: status, urgency, bloodGroup, city
 */
exports.getAllRequests = async (req, res) => {
  try {
    const { status, urgency, bloodGroup, city } = req.query;

    if (isMongoConnected()) {
      let query = {};
      if (status && status !== 'all') query.status = status;
      if (urgency && urgency !== 'all') query.urgency = urgency;
      if (bloodGroup && bloodGroup !== 'all') query.bloodGroup = bloodGroup;
      if (city && city.trim() !== '') query.city = { $regex: new RegExp(city.trim(), 'i') };

      const requests = await BloodRequest.find(query).sort({ createdAt: -1 });
      return res.status(200).json({
        success: true,
        count: requests.length,
        data: requests
      });
    }

    let filtered = [...memoryStore.requests];
    if (status && status !== 'all') {
      filtered = filtered.filter(r => r.status.toLowerCase() === status.toLowerCase());
    }
    if (urgency && urgency !== 'all') {
      filtered = filtered.filter(r => r.urgency.toLowerCase() === urgency.toLowerCase());
    }
    if (bloodGroup && bloodGroup !== 'all') {
      filtered = filtered.filter(r => r.bloodGroup.toUpperCase() === bloodGroup.trim().toUpperCase());
    }
    if (city && city.trim() !== '') {
      const c = city.trim().toLowerCase();
      filtered = filtered.filter(r => r.city.toLowerCase().includes(c));
    }

    return res.status(200).json({
      success: true,
      count: filtered.length,
      data: filtered
    });
  } catch (err) {
    return res.status(500).json({
      success: false,
      message: 'Failed to retrieve blood requests',
      error: err.message
    });
  }
};

/**
 * GET /api/requests/recent
 * Returns active spotlight requests for ticker & home page
 */
exports.getRecentEmergencies = async (req, res) => {
  try {
    if (isMongoConnected()) {
      const active = await BloodRequest.find({
        status: { $in: ['Pending', 'In Progress'] }
      })
        .sort({ urgency: 1, createdAt: -1 })
        .limit(6);

      return res.status(200).json({
        success: true,
        count: active.length,
        data: active
      });
    }

    const active = memoryStore.requests
      .filter(r => r.status === 'Pending' || r.status === 'In Progress')
      .slice(0, 6);

    return res.status(200).json({
      success: true,
      count: active.length,
      data: active
    });
  } catch (err) {
    return res.status(500).json({ success: false, message: 'Failed to fetch emergency feed' });
  }
};

/**
 * GET /api/requests/:id
 */
exports.getRequestById = async (req, res) => {
  try {
    const { id } = req.params;

    if (isMongoConnected()) {
      const reqDoc = await BloodRequest.findById(id);
      if (!reqDoc) return res.status(404).json({ success: false, message: 'Request not found' });
      return res.status(200).json({ success: true, data: reqDoc });
    }

    const reqDoc = memoryStore.requests.find(r => String(r._id) === String(id));
    if (!reqDoc) return res.status(404).json({ success: false, message: 'Request not found' });
    return res.status(200).json({ success: true, data: reqDoc });
  } catch (err) {
    return res.status(500).json({ success: false, message: 'Error retrieving request', error: err.message });
  }
};

/**
 * POST /api/requests
 * Submit a new emergency blood requirement
 */
exports.createRequest = async (req, res) => {
  try {
    const {
      patientName,
      hospitalName,
      bloodGroup,
      units,
      urgency = 'Urgent',
      city,
      wardOrDept = 'Emergency Dept',
      contactPerson,
      contactPhone,
      reason = 'Clinical Requisition',
      notes = ''
    } = req.body;

    if (!patientName || !hospitalName || !bloodGroup || !units || !city || !contactPerson || !contactPhone) {
      return res.status(400).json({
        success: false,
        message: 'Please fill in all mandatory fields: patientName, hospitalName, bloodGroup, units, city, contactPerson, contactPhone'
      });
    }

    const validBloodGroups = ['A+', 'A-', 'B+', 'B-', 'AB+', 'AB-', 'O+', 'O-'];
    if (!validBloodGroups.includes(bloodGroup.trim())) {
      return res.status(400).json({
        success: false,
        message: `Invalid blood group. Must be one of: ${validBloodGroups.join(', ')}`
      });
    }

    const unitsCount = Number(units);
    if (isNaN(unitsCount) || unitsCount < 1) {
      return res.status(400).json({
        success: false,
        message: 'Units needed must be at least 1 unit'
      });
    }

    if (isMongoConnected()) {
      const newRequest = await BloodRequest.create({
        patientName: patientName.trim(),
        hospitalName: hospitalName.trim(),
        bloodGroup: bloodGroup.trim(),
        units: unitsCount,
        urgency,
        city: city.trim(),
        wardOrDept: wardOrDept.trim(),
        contactPerson: contactPerson.trim(),
        contactPhone: contactPhone.trim(),
        reason: reason.trim(),
        notes: notes ? notes.trim() : '',
        status: 'Pending'
      });

      return res.status(201).json({
        success: true,
        message: 'Emergency Blood Requisition broadcasted successfully to all verified donors!',
        data: newRequest
      });
    }

    const newRequest = {
      _id: '66f2' + Math.random().toString(16).substring(2, 14).padEnd(20, '0'),
      patientName: patientName.trim(),
      hospitalName: hospitalName.trim(),
      bloodGroup: bloodGroup.trim(),
      units: unitsCount,
      urgency,
      city: city.trim(),
      wardOrDept: wardOrDept.trim(),
      contactPerson: contactPerson.trim(),
      contactPhone: contactPhone.trim(),
      reason: reason.trim(),
      notes: notes ? notes.trim() : '',
      status: 'Pending',
      createdAt: new Date()
    };

    memoryStore.requests.unshift(newRequest);

    return res.status(201).json({
      success: true,
      message: 'Emergency Blood Requisition broadcasted successfully to all verified donors!',
      data: newRequest
    });
  } catch (err) {
    return res.status(400).json({
      success: false,
      message: 'Failed to create blood request',
      error: err.message
    });
  }
};

/**
 * PATCH /api/requests/:id/status
 * Update status (Pending -> In Progress -> Fulfilled -> Cancelled)
 */
exports.updateRequestStatus = async (req, res) => {
  try {
    const { id } = req.params;
    const { status } = req.body;

    const validStatuses = ['Pending', 'In Progress', 'Fulfilled', 'Cancelled'];
    if (!validStatuses.includes(status)) {
      return res.status(400).json({
        success: false,
        message: `Invalid status. Valid values are: ${validStatuses.join(', ')}`
      });
    }

    if (isMongoConnected()) {
      const updated = await BloodRequest.findByIdAndUpdate(
        id,
        { status },
        { new: true, runValidators: true }
      );
      if (!updated) return res.status(404).json({ success: false, message: 'Request not found' });
      return res.status(200).json({
        success: true,
        message: `Requisition status updated to: ${status}`,
        data: updated
      });
    }

    const r = memoryStore.requests.find(item => String(item._id) === String(id));
    if (!r) return res.status(404).json({ success: false, message: 'Request not found' });

    r.status = status;
    return res.status(200).json({
      success: true,
      message: `Requisition status updated to: ${status}`,
      data: r
    });
  } catch (err) {
    return res.status(500).json({ success: false, message: 'Failed to update status', error: err.message });
  }
};

/**
 * DELETE /api/requests/:id
 */
exports.deleteRequest = async (req, res) => {
  try {
    const { id } = req.params;

    if (isMongoConnected()) {
      const deleted = await BloodRequest.findByIdAndDelete(id);
      if (!deleted) return res.status(404).json({ success: false, message: 'Request not found' });
      return res.status(200).json({ success: true, message: 'Requisition deleted successfully' });
    }

    const idx = memoryStore.requests.findIndex(item => String(item._id) === String(id));
    if (idx === -1) return res.status(404).json({ success: false, message: 'Request not found' });

    memoryStore.requests.splice(idx, 1);
    return res.status(200).json({ success: true, message: 'Requisition deleted successfully' });
  } catch (err) {
    return res.status(500).json({ success: false, message: 'Delete failed', error: err.message });
  }
};
