require('dotenv').config();
const express = require('express');
const path = require('path');
const cors = require('cors');
const { connectDB, isMongoConnected } = require('./db');

// Route imports
const donorRoutes = require('./routes/donorRoutes');
const requestRoutes = require('./routes/requestRoutes');
const userRoutes = require('./routes/userRoutes');

const app = express();
const PORT = process.env.PORT || 5000;

// Connect to Database
connectDB();

// Core Middlewares
app.use(cors());
app.use(express.json());
app.use(express.urlencoded({ extended: true }));

// Educational viva request logger
app.use((req, res, next) => {
  const start = Date.now();
  res.on('finish', () => {
    const duration = Date.now() - start;
    console.log(`[HTTP] ${req.method} ${req.originalUrl} - ${res.statusCode} (${duration}ms)`);
  });
  next();
});

// Serve frontend static assets directly from root and /frontend
const frontendPath = path.join(__dirname, '..', 'frontend');
app.use(express.static(frontendPath));
app.use('/frontend', express.static(frontendPath));

// REST API Endpoints
app.use('/api/donors', donorRoutes);
app.use('/api/requests', requestRoutes);
app.use('/api/users', userRoutes);

// Health check endpoint for viva demonstration
app.get('/api/health', (req, res) => {
  res.status(200).json({
    status: 'online',
    timestamp: new Date().toISOString(),
    service: 'HemoPulse Blood Donor Finder API',
    database: isMongoConnected() ? 'MongoDB Connected' : 'In-Memory / Local Active (MongoDB Ready)',
    version: '1.0.0'
  });
});

// Default fallback to index.html for root route
app.get('/', (req, res) => {
  res.sendFile(path.join(frontendPath, 'index.html'));
});

// Centralized 404 handler for API routes
app.use('/api/*', (req, res) => {
  res.status(404).json({
    success: false,
    message: `API endpoint '${req.originalUrl}' not found on this server.`
  });
});

// Global Centralized Error Handling Middleware
app.use((err, req, res, next) => {
  console.error('[Error Middleware]', err.stack || err.message);
  res.status(err.status || 500).json({
    success: false,
    message: err.message || 'Internal Server Error',
    error: process.env.NODE_ENV === 'development' ? err : {}
  });
});

// Start listening
app.listen(PORT, () => {
  console.log('================================================================');
  console.log(`🩸 HemoPulse Blood Donor Finder Web Server is running!`);
  console.log(`📡 URL: http://localhost:${PORT}`);
  console.log(`💻 Frontend UI: http://localhost:${PORT}/index.html`);
  console.log(`🩺 API Health:  http://localhost:${PORT}/api/health`);
  console.log('================================================================');
});
