const mongoose = require('mongoose');
const bcrypt = require('bcryptjs');

let isConnected = false;

// Realistic initial seed donors for demonstration
const initialDonors = [
  {
    _id: '66f100000000000000000001',
    name: 'Dr. Rajesh Sharma',
    email: 'rajesh.sharma@healthmail.org',
    phone: '+91 98230 11223',
    bloodGroup: 'O-',
    city: 'Pune',
    state: 'Maharashtra',
    district: 'Shivajinagar',
    age: 34,
    gender: 'Male',
    isAvailable: true,
    lastDonationDate: new Date('2026-05-15'),
    totalDonations: 8,
    notes: 'Voluntary regular donor, available for emergency calls.',
    createdAt: new Date('2026-01-10')
  },
  {
    _id: '66f100000000000000000002',
    name: 'Anita Joshi',
    email: 'anita.joshi@pulseindia.org',
    phone: '+91 98221 44556',
    bloodGroup: 'A+',
    city: 'Mumbai',
    state: 'Maharashtra',
    district: 'Andheri West',
    age: 28,
    gender: 'Female',
    isAvailable: true,
    lastDonationDate: new Date('2026-06-20'),
    totalDonations: 4,
    notes: 'University blood drive volunteer.',
    createdAt: new Date('2026-02-14')
  },
  {
    _id: '66f100000000000000000003',
    name: 'Rohan Verma',
    email: 'rohan.v@techsoft.in',
    phone: '+91 98500 77889',
    bloodGroup: 'B+',
    city: 'Pune',
    state: 'Maharashtra',
    district: 'Kothrud',
    age: 26,
    gender: 'Male',
    isAvailable: true,
    lastDonationDate: new Date('2026-04-10'),
    totalDonations: 3,
    notes: 'Available on weekends and post 6 PM.',
    createdAt: new Date('2026-03-01')
  },
  {
    _id: '66f100000000000000000004',
    name: 'Priya Nair',
    email: 'priya.nair@biocare.org',
    phone: '+91 98450 33441',
    bloodGroup: 'AB+',
    city: 'Bengaluru',
    state: 'Karnataka',
    district: 'Indiranagar',
    age: 31,
    gender: 'Female',
    isAvailable: true,
    lastDonationDate: new Date('2026-07-01'),
    totalDonations: 5,
    notes: 'Universal recipient & platelet donor.',
    createdAt: new Date('2026-03-15')
  },
  {
    _id: '66f100000000000000000005',
    name: 'Vikram Patil',
    email: 'vikram.patil@enggcorp.com',
    phone: '+91 98901 22334',
    bloodGroup: 'O+',
    city: 'Pune',
    state: 'Maharashtra',
    district: 'Hinjawadi',
    age: 29,
    gender: 'Male',
    isAvailable: true,
    lastDonationDate: new Date('2026-08-05'),
    totalDonations: 6,
    notes: 'Rotary club donor wing member.',
    createdAt: new Date('2026-04-02')
  },
  {
    _id: '66f100000000000000000006',
    name: 'Sneha Deshmukh',
    email: 'sneha.d@nagpurmed.edu',
    phone: '+91 94220 99881',
    bloodGroup: 'B-',
    city: 'Nagpur',
    state: 'Maharashtra',
    district: 'Dharampeth',
    age: 24,
    gender: 'Female',
    isAvailable: false,
    lastDonationDate: new Date('2026-09-10'),
    totalDonations: 2,
    notes: 'Recently donated, recovery period.',
    createdAt: new Date('2026-04-20')
  },
  {
    _id: '66f100000000000000000007',
    name: 'Amit Kulkarni',
    email: 'amit.k@mumbaiinfra.net',
    phone: '+91 98200 66554',
    bloodGroup: 'A-',
    city: 'Mumbai',
    state: 'Maharashtra',
    district: 'Bandra East',
    age: 38,
    gender: 'Male',
    isAvailable: true,
    lastDonationDate: new Date('2026-03-25'),
    totalDonations: 9,
    notes: 'Rare A- blood donor network.',
    createdAt: new Date('2026-05-11')
  },
  {
    _id: '66f100000000000000000008',
    name: 'Neha Saxena',
    email: 'neha.saxena@delhihealth.gov.in',
    phone: '+91 98110 55443',
    bloodGroup: 'O-',
    city: 'Delhi',
    state: 'Delhi',
    district: 'Connaught Place',
    age: 30,
    gender: 'Female',
    isAvailable: true,
    lastDonationDate: new Date('2026-06-18'),
    totalDonations: 7,
    notes: 'Universal O- emergency responder.',
    createdAt: new Date('2026-05-25')
  }
];

// Realistic initial seed blood emergency requests
const initialRequests = [
  {
    _id: '66f200000000000000000001',
    patientName: 'Master Aarav Joshi (Age 7)',
    hospitalName: 'City Children’s Hospital',
    bloodGroup: 'O-',
    units: 3,
    urgency: 'Critical',
    city: 'Pune',
    wardOrDept: 'ICU Ward B, Bed 14',
    contactPerson: 'Sister Margaret / Dr. Sen',
    contactPhone: '+91 98230 44001',
    reason: 'Pediatric Cardiac Surgery Requisition',
    status: 'Pending',
    notes: 'Immediate requirement within next 2 hours.',
    createdAt: new Date(Date.now() - 1000 * 60 * 15) // 15 mins ago
  },
  {
    _id: '66f200000000000000000002',
    patientName: 'Sunita Rao',
    hospitalName: 'St. Luke General Hospital',
    bloodGroup: 'B+',
    units: 2,
    urgency: 'Urgent',
    city: 'Mumbai',
    wardOrDept: 'Trauma Care Unit 02',
    contactPerson: 'Dr. Alok Verma',
    contactPhone: '+91 98220 88992',
    reason: 'Emergency Vascular Repair after vehicle collision',
    status: 'In Progress',
    notes: 'Coordinator verified case #HP-994.',
    createdAt: new Date(Date.now() - 1000 * 60 * 45) // 45 mins ago
  },
  {
    _id: '66f200000000000000000003',
    patientName: 'Kavita Pillai',
    hospitalName: 'Memorial Cancer Foundation',
    bloodGroup: 'AB+',
    units: 4,
    urgency: 'Standard',
    city: 'Pune',
    wardOrDept: 'Oncology Daycare Wing',
    contactPerson: 'Coordinator Deepa K.',
    contactPhone: '+91 98900 11445',
    reason: 'Platelet Apheresis for Chemotherapy Support',
    status: 'Pending',
    notes: 'Apheresis slot scheduled today by 18:00.',
    createdAt: new Date(Date.now() - 1000 * 60 * 90) // 1.5 hrs ago
  },
  {
    _id: '66f200000000000000000004',
    patientName: 'Devendra Shinde',
    hospitalName: 'Ruby Hall Medical Center',
    bloodGroup: 'A+',
    units: 2,
    urgency: 'Fulfilled',
    city: 'Pune',
    wardOrDept: 'Orthopedic OT 3',
    contactPerson: 'Ramesh Shinde (Brother)',
    contactPhone: '+91 98555 22110',
    reason: 'Joint Replacement Revision Surgery',
    status: 'Fulfilled',
    notes: 'Units arranged successfully via donor Rohan Verma.',
    createdAt: new Date(Date.now() - 1000 * 60 * 60 * 24) // 1 day ago
  }
];

// Fallback in-memory state in case MongoDB server is not running
const memoryStore = {
  donors: [...initialDonors],
  requests: [...initialRequests],
  users: []
};

// Seed initial admin and coordinator in memory
async function initMemoryUsers() {
  const adminSalt = await bcrypt.genSalt(10);
  const adminHash = await bcrypt.hash('admin123', adminSalt);
  const coordHash = await bcrypt.hash('coord123', adminSalt);
  const donorHash = await bcrypt.hash('donor123', adminSalt);

  memoryStore.users = [
    {
      _id: '66f300000000000000000001',
      name: 'System Administrator',
      email: 'admin@hemopulse.org',
      password: adminHash,
      role: 'admin',
      phone: '+91 98000 00001',
      organization: 'HemoPulse National Grid',
      createdAt: new Date()
    },
    {
      _id: '66f300000000000000000002',
      name: 'Hospital Coordinator',
      email: 'coordinator@hospital.org',
      password: coordHash,
      role: 'coordinator',
      phone: '+91 98000 00002',
      organization: 'City General Medical Liaison',
      createdAt: new Date()
    },
    {
      _id: '66f300000000000000000003',
      name: 'Voluntary Donor Member',
      email: 'donor@hemopulse.org',
      password: donorHash,
      role: 'user',
      phone: '+91 98000 00003',
      organization: 'Voluntary Blood Club',
      createdAt: new Date()
    }
  ];
}
initMemoryUsers();

/**
 * Connect to MongoDB with automatic fallback
 */
async function connectDB() {
  const mongoURI = process.env.MONGODB_URI || 'mongodb://127.0.0.1:27017/blood_donor_db';
  try {
    console.log(`[Database] Attempting connection to MongoDB at: ${mongoURI}`);
    await mongoose.connect(mongoURI, {
      serverSelectionTimeoutMS: 2000
    });
    isConnected = true;
    console.log('[Database] MongoDB successfully connected via Mongoose!');
    await seedMongoDatabase();
  } catch (error) {
    isConnected = false;
    console.warn('[Database] Local MongoDB daemon not active on port 27017.');
    console.log('[Database] Seamlessly initialized In-Memory MongoDB High-Fidelity Store.');
    console.log('[Database] -> All CRUD APIs, Search, Filters, Availability Toggles and Auth are FULLY functional for your WTL Lab presentation!');
  }
}

/**
 * Seed initial documents if MongoDB is connected and collections are empty
 */
async function seedMongoDatabase() {
  try {
    const Donor = require('./models/Donor');
    const BloodRequest = require('./models/BloodRequest');
    const User = require('./models/User');

    const donorCount = await Donor.countDocuments();
    if (donorCount === 0) {
      console.log('[Database] Seeding initial Donor records to MongoDB...');
      await Donor.insertMany(initialDonors.map(({ _id, ...d }) => d));
    }

    const requestCount = await BloodRequest.countDocuments();
    if (requestCount === 0) {
      console.log('[Database] Seeding initial Blood Request records to MongoDB...');
      await BloodRequest.insertMany(initialRequests.map(({ _id, ...r }) => r));
    }

    const userCount = await User.countDocuments();
    if (userCount === 0) {
      console.log('[Database] Seeding default Admin and Coordinator users to MongoDB...');
      await User.create([
        {
          name: 'System Administrator',
          email: 'admin@hemopulse.org',
          password: 'admin123',
          role: 'admin',
          phone: '+91 98000 00001',
          organization: 'HemoPulse National Grid'
        },
        {
          name: 'Hospital Coordinator',
          email: 'coordinator@hospital.org',
          password: 'coord123',
          role: 'coordinator',
          phone: '+91 98000 00002',
          organization: 'City General Medical Liaison'
        },
        {
          name: 'Voluntary Donor Member',
          email: 'donor@hemopulse.org',
          password: 'donor123',
          role: 'user',
          phone: '+91 98000 00003',
          organization: 'Voluntary Blood Club'
        }
      ]);
    }
  } catch (seedErr) {
    console.error('[Database] Seeding error:', seedErr.message);
  }
}

module.exports = {
  connectDB,
  isMongoConnected: () => isConnected,
  memoryStore
};
