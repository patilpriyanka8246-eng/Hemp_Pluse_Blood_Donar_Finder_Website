const express = require('express');
const router = express.Router();
const donorController = require('../controllers/donorController');

// Stats endpoint (placed before :id route so it doesn't get treated as an ID)
router.get('/stats/overview', donorController.getStats);

// Donor CRUD
router.get('/', donorController.getAllDonors);
router.get('/:id', donorController.getDonorById);
router.post('/', donorController.createDonor);
router.put('/:id', donorController.updateDonor);
router.patch('/:id/availability', donorController.toggleAvailability);
router.delete('/:id', donorController.deleteDonor);

module.exports = router;
