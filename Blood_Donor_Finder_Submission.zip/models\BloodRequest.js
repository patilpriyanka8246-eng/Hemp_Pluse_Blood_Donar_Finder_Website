const mongoose = require('mongoose');

const bloodRequestSchema = new mongoose.Schema({
  patientName: {
    type: String,
    required: [true, 'Patient name is required'],
    trim: true
  },
  hospitalName: {
    type: String,
    required: [true, 'Hospital or Clinic name is required'],
    trim: true
  },
  bloodGroup: {
    type: String,
    required: [true, 'Required blood group is required'],
    enum: {
      values: ['A+', 'A-', 'B+', 'B-', 'AB+', 'AB-', 'O+', 'O-'],
      message: '{VALUE} is not a valid blood group'
    }
  },
  units: {
    type: Number,
    required: [true, 'Number of blood units needed is required'],
    min: [1, 'At least 1 unit must be requested'],
    default: 1
  },
  urgency: {
    type: String,
    enum: ['Critical', 'Urgent', 'Standard'],
    default: 'Urgent'
  },
  city: {
    type: String,
    required: [true, 'City / Location is required'],
    trim: true
  },
  wardOrDept: {
    type: String,
    default: 'Emergency / General',
    trim: true
  },
  contactPerson: {
    type: String,
    required: [true, 'Contact person name is required'],
    trim: true
  },
  contactPhone: {
    type: String,
    required: [true, 'Contact phone number is required'],
    trim: true,
    match: [/^[0-9+ -]{7,15}$/, 'Please enter a valid contact phone number']
  },
  reason: {
    type: String,
    default: 'Surgery / Medical Procedure',
    trim: true
  },
  status: {
    type: String,
    enum: ['Pending', 'In Progress', 'Fulfilled', 'Cancelled'],
    default: 'Pending'
  },
  notes: {
    type: String,
    default: ''
  },
  createdAt: {
    type: Date,
    default: Date.now
  }
});

// Indexes for sorting emergencies and city filtering
bloodRequestSchema.index({ status: 1, urgency: 1, createdAt: -1 });
bloodRequestSchema.index({ bloodGroup: 1, city: 1 });

module.exports = mongoose.model('BloodRequest', bloodRequestSchema);
