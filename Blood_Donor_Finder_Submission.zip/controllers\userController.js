const User = require('../models/User');
const bcrypt = require('bcryptjs');
const jwt = require('jsonwebtoken');
const { isMongoConnected, memoryStore } = require('../db');

const JWT_SECRET = process.env.JWT_SECRET || 'blood_donor_finder_secret_key_wtl_2026';

function generateToken(user) {
  return jwt.sign(
    { id: user._id, email: user.email, role: user.role, name: user.name },
    JWT_SECRET,
    { expiresIn: '7d' }
  );
}

/**
 * POST /api/users/register
 */
exports.register = async (req, res) => {
  try {
    const { name, email, password, role = 'user', phone = '', organization = '' } = req.body;

    if (!name || !email || !password) {
      return res.status(400).json({
        success: false,
        message: 'Please provide name, email and password'
      });
    }

    if (password.length < 6) {
      return res.status(400).json({
        success: false,
        message: 'Password must be at least 6 characters long'
      });
    }

    const cleanEmail = email.trim().toLowerCase();

    if (isMongoConnected()) {
      const existingUser = await User.findOne({ email: cleanEmail });
      if (existingUser) {
        return res.status(400).json({
          success: false,
          message: 'An account with this email already exists'
        });
      }

      const user = await User.create({
        name: name.trim(),
        email: cleanEmail,
        password,
        role,
        phone: phone.trim(),
        organization: organization.trim()
      });

      const token = generateToken(user);

      return res.status(201).json({
        success: true,
        message: 'Registration successful! Welcome to HemoPulse.',
        token,
        user: {
          id: user._id,
          name: user.name,
          email: user.email,
          role: user.role,
          phone: user.phone,
          organization: user.organization
        }
      });
    }

    // In-memory fallback
    const existing = memoryStore.users.find(u => u.email.toLowerCase() === cleanEmail);
    if (existing) {
      return res.status(400).json({
        success: false,
        message: 'An account with this email already exists'
      });
    }

    const salt = await bcrypt.genSalt(10);
    const hashedPassword = await bcrypt.hash(password, salt);

    const newUser = {
      _id: '66f3' + Math.random().toString(16).substring(2, 14).padEnd(20, '0'),
      name: name.trim(),
      email: cleanEmail,
      password: hashedPassword,
      role,
      phone: phone.trim(),
      organization: organization.trim(),
      createdAt: new Date()
    };

    memoryStore.users.push(newUser);
    const token = generateToken(newUser);

    return res.status(201).json({
      success: true,
      message: 'Registration successful! Welcome to HemoPulse.',
      token,
      user: {
        id: newUser._id,
        name: newUser.name,
        email: newUser.email,
        role: newUser.role,
        phone: newUser.phone,
        organization: newUser.organization
      }
    });
  } catch (err) {
    return res.status(500).json({
      success: false,
      message: 'Registration error',
      error: err.message
    });
  }
};

/**
 * POST /api/users/login
 */
exports.login = async (req, res) => {
  try {
    const { email, password } = req.body;

    if (!email || !password) {
      return res.status(400).json({
        success: false,
        message: 'Please provide both email and password'
      });
    }

    const cleanEmail = email.trim().toLowerCase();

    if (isMongoConnected()) {
      const user = await User.findOne({ email: cleanEmail });
      if (!user) {
        return res.status(401).json({
          success: false,
          message: 'Invalid credentials. User with this email does not exist.'
        });
      }

      const isMatch = await user.comparePassword(password);
      if (!isMatch) {
        return res.status(401).json({
          success: false,
          message: 'Invalid password. Please check your credentials.'
        });
      }

      const token = generateToken(user);
      return res.status(200).json({
        success: true,
        message: `Welcome back, ${user.name}!`,
        token,
        user: {
          id: user._id,
          name: user.name,
          email: user.email,
          role: user.role,
          phone: user.phone,
          organization: user.organization
        }
      });
    }

    // In-memory fallback
    const user = memoryStore.users.find(u => u.email.toLowerCase() === cleanEmail);
    if (!user) {
      return res.status(401).json({
        success: false,
        message: 'Invalid credentials. User not found in directory.'
      });
    }

    const isMatch = await bcrypt.compare(password, user.password);
    if (!isMatch) {
      return res.status(401).json({
        success: false,
        message: 'Invalid password. Please check your credentials.'
      });
    }

    const token = generateToken(user);
    return res.status(200).json({
      success: true,
      message: `Welcome back, ${user.name}!`,
      token,
      user: {
        id: user._id,
        name: user.name,
        email: user.email,
        role: user.role,
        phone: user.phone,
        organization: user.organization
      }
    });
  } catch (err) {
    return res.status(500).json({
      success: false,
      message: 'Login failure',
      error: err.message
    });
  }
};

/**
 * GET /api/users/profile
 */
exports.getProfile = (req, res) => {
  const authHeader = req.headers.authorization;
  if (!authHeader || !authHeader.startsWith('Bearer ')) {
    return res.status(401).json({ success: false, message: 'Authorization token required' });
  }

  const token = authHeader.split(' ')[1];
  try {
    const decoded = jwt.verify(token, JWT_SECRET);
    return res.status(200).json({ success: true, user: decoded });
  } catch (err) {
    return res.status(401).json({ success: false, message: 'Invalid or expired session token' });
  }
};

/**
 * GET /api/users
 */
exports.getAllUsers = async (req, res) => {
  try {
    if (isMongoConnected()) {
      const users = await User.find({}, '-password').sort({ createdAt: -1 });
      return res.status(200).json({ success: true, count: users.length, data: users });
    }

    const safeUsers = memoryStore.users.map(({ password, ...u }) => u);
    return res.status(200).json({ success: true, count: safeUsers.length, data: safeUsers });
  } catch (err) {
    return res.status(500).json({ success: false, message: 'Server error' });
  }
};
